
# player.py
class Player:
    def __init__(self):
        self.health = 100
        self.inventory = []

    def move(self, direction):
        print(f"Player moves {direction}")

    def attack(self, target):
        print(f"Attacking {target}")
        target.take_damage(10)
