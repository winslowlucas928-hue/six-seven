
// Player.h
#pragma once
#include <string>
#include <vector>

class Player {
public:
    Player();
    void Move(std::string direction);
    void Attack(class Enemy* target);
    void TakeDamage(int amount);
private:
    int health;
    std::vector<std::string> inventory;
};
