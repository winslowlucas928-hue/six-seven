ChronoCore: Fully Open-World Base Game Package
Includes GDScript code, 3D model placeholders, and sound structure.
Replace assets as needed.